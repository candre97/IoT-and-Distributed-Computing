#include "CmdLBTRSSI.h"

CmdLBTRSSI::CmdLBTRSSI()
:
  Command("LBT RSSI", "AT+LBTRSSI", "READ LBT RSSI", "(-128-0)")
{
    _queryable = true;
}

uint32_t CmdLBTRSSI::action(const std::vector<std::string>& args)
{
    CommandTerminal::Serial()->writef("%d\r\n", CommandTerminal::Dot()->lbtRssi());
    return 0;
}

bool CmdLBTRSSI::verify(const std::vector<std::string>& args)
{
    return true;
}
